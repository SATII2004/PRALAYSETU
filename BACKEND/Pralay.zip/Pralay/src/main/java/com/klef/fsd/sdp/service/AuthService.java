package com.klef.fsd.sdp.service;

import com.klef.fsd.sdp.dto.ForgotPasswordRequest;
import com.klef.fsd.sdp.dto.LoginRequest;
import com.klef.fsd.sdp.dto.RegisterRequest;

public interface AuthService {
  void register(RegisterRequest request);
  boolean login(LoginRequest request);
  void forgotPassword(ForgotPasswordRequest request);
}