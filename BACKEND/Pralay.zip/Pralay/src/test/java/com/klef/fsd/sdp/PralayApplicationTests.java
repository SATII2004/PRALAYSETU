package com.klef.fsd.sdp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PralayApplicationTests {

	@Test
	void contextLoads() {
	}

}
